import streamlit as st
import plotly.io as pio

st.set_page_config(layout="wide")

st.write("# CXC 2025: Federato Challenge")
st.write("Kenny Guo, Julia Zhu and Adeline Su")